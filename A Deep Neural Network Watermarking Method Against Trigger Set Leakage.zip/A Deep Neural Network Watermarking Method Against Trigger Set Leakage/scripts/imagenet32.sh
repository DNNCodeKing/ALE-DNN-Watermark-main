# train a clean model
python main.py --config config/imagenet32/imagenet32_clean.yaml --runname imagenet32_clean

#train a anti-forge model
python main.py --config config/imagenet32/imagenet32_forge.yaml --runname imagenet32_forge

# train a watermarked model (from pretrained)
python main.py --config config/imagenet32/imagenet32_watermark.yaml --runname imagenet32_watermark --save_trigger


#evaluate the anti-forge
python main.py --config config/imagenet32/imagenet32_evaluate.yaml

#check trigger on clean model
python main.py --config config/imagenet32/imagenet32_clean_evaluate.yaml

# evaluate a watermarked model
python main.py --action evaluate --dataset imagenet32 --arch resnet18 --checkpoint_path /path/to/last.pth

# attack
# hard label extraction
python main.py --action attack --dataset imagenet32 --arch resnet18 --epochs 25 --attack_type retrain --runname retrain \
  --victim_path /path/to/last.pth

# knowledge distillation with mobile net
python main.py --action attack --dataset imagenet32 --arch mobile --epochs 25 --attack_type distill --runname distill  \
  --victim_path /path/to/last.pth
# knockoff nets
python main.py --action attack --dataset imagenet32 --arch resnet18 --epochs 25 --attack_type knockoff --runname knockoff  \
  --victim_path /path/to/last.pth

# model fine-tuning
python main.py --action attack --dataset imagenet32 --arch resnet18 --epochs 10 --attack_type rtal --runname rtal \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset imagenet32 --arch resnet18 --epochs 10 --attack_type ftal --runname ftal \
  --victim_path /path/to/last.pth

# model compression
python main.py --action attack --dataset imagenet32 --arch resnet18 --attack_type quantization --runname quantization \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset imagenet32 --arch resnet18 --attack_type prune --runname pruning  \
  --victim_path /path/to/last.pth

# cross architecture hard label extraction
python main.py --action attack --dataset imagenet32 --arch VGG16 --epochs 25 --attack_type cross --runname vgg16_cross_retraining  \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset imagenet32 --arch senet --epochs 25 --attack_type cross --runname senet_cross_retraining  \
  --victim_path /path/to/last.pth

# double extraction
python main.py --action attack --dataset imagenet32 --arch resnet18 --epochs 25 --attack_type retrain --runname double_extraction \
  --victim_path /path/to/first_extraction_model.pth

# anti-leakage
python main.py --config config/imagenet32/encrypt_trigger.yaml

python main.py --config config/imagenet32/decrypt_trigger.yaml
