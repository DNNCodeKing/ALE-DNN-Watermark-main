# train a clean model
python main.py --config config/fashion/fashion_clean.yaml --runname fashion_clean

# train a watermarked model (from pretrained)
python main.py --config config/fashion/fashion_watermark.yaml --runname fashion_watermark --save_trigger

#check trigger on clean model
python main.py --config config/fashion/fashion_clean_evaluate.yaml

#evaluate forge
python main.py --config config/fashion/fashion_evaluate.yaml

# evaluate a watermarked model
python main.py --action evaluate --dataset fashion --arch vanilla --checkpoint_path /path/to/last.pth

# attack
python main.py --action attack --dataset fashion --arch vanilla --epochs 50 --attack_type retrain --runname retrain \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch simple --epochs 50 --attack_type distill --runname distill  \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch vanilla --epochs 50 --attack_type knockoff --runname knockoff  \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch vanilla --epochs 10 --attack_type rtal --runname rtal \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch vanilla --epochs 10 --attack_type ftal --runname ftal \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch vanilla --attack_type quantization --runname quantization \
  --victim_path /path/to/last.pth

python main.py --action attack --dataset fashion --arch vanilla --attack_type prune --runname pruning  \
  --victim_path /path/to/last.pth

# anti-leakage
python main.py --config config/fashion/encrypt_trigger.yaml

python main.py --config config/fashion/decrypt_trigger.yaml
