import os
import hashlib
import io
import struct
import torch
import numpy as np
from PIL import Image
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding


def derive_key(password: str, salt: bytes, key_length=32) -> bytes:
    """PBKDF2 Documentation. AES-256 Documentation."""
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000, dklen=key_length)


def encrypt_image(image_tensor, password: str) -> bytes:
    """Documentation. -> Documentation. (salt+iv+ciphertext)"""
    arr = image_tensor.detach().permute(1,2,0).cpu().numpy()
    if arr.dtype != np.uint8:
        arr = (arr * 255).clip(0, 255).astype(np.uint8)
    pil_img = Image.fromarray(arr)
    buf = io.BytesIO()
    pil_img.save(buf, format='PNG')
    plaintext = buf.getvalue()
    salt = os.urandom(16)
    iv = os.urandom(16)
    key = derive_key(password, salt)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded) + encryptor.finalize()
    return salt + iv + ciphertext


def decrypt_image(encrypted_data: bytes, password: str) -> torch.Tensor:
    """Documentation. -> Documentation."""
    if len(encrypted_data) < 32:
        raise ValueError("Invalid encrypted data")
    salt = encrypted_data[:16]
    iv = encrypted_data[16:32]
    ciphertext = encrypted_data[32:]
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded) + unpadder.finalize()
    pil_img = Image.open(io.BytesIO(plaintext))
    img_tensor = torch.from_numpy(np.array(pil_img)).float() / 255.0
    if img_tensor.dim() == 2:
        img_tensor = img_tensor.unsqueeze(0)
    else:
        img_tensor = img_tensor.permute(2, 0, 1)
    return img_tensor


def encrypt_labels(labels, password: str) -> bytes:
    """Documentation. -> Documentation."""
    if isinstance(labels, torch.Tensor):
        labels = labels.tolist()
    plaintext = torch.tensor(labels, dtype=torch.long).numpy().tobytes()
    salt = os.urandom(16)
    iv = os.urandom(16)
    key = derive_key(password, salt)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded) + encryptor.finalize()
    return salt + iv + ciphertext


def decrypt_labels(encrypted_data: bytes, password: str) -> list:
    """Documentation. -> Documentation."""
    if len(encrypted_data) < 32:
        raise ValueError("Invalid encrypted data")
    salt = encrypted_data[:16]
    iv = encrypted_data[16:32]
    ciphertext = encrypted_data[32:]
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded) + unpadder.finalize()
    return torch.frombuffer(plaintext, dtype=torch.long).tolist()


def encrypt_trigger_object(trigger_obj, password: str) -> bytes:
    """Documentation. Key Documentation. -> Documentation."""
    buffer = io.BytesIO()
    torch.save(trigger_obj, buffer)
    plaintext = buffer.getvalue()
    salt = os.urandom(16)
    iv = os.urandom(16)
    key = derive_key(password, salt)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded) + encryptor.finalize()
    return salt + iv + ciphertext


def decrypt_trigger_object(encrypted_data: bytes, password: str):
    """Documentation. -> Documentation. Key Documentation."""
    if len(encrypted_data) < 32:
        raise ValueError("Invalid encrypted data")
    salt = encrypted_data[:16]
    iv = encrypted_data[16:32]
    ciphertext = encrypted_data[32:]
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    plaintext = unpadder.update(padded) + unpadder.finalize()
    buffer = io.BytesIO(plaintext)
    return torch.load(buffer, map_location='cpu', weights_only=False)

def encrypt_image_to_noise_image(image_tensor, password: str):
    """
    将图像加密为噪声 PNG 图片（仍为有效 PNG 格式，但内容加密）
    保留原始通道数（单通道灰度图会生成灰度噪声图）。
    返回: (noise_img_PIL, (original_width, original_height, original_channels))
    """
    arr = image_tensor.detach().permute(1,2,0).cpu().numpy()
    if arr.dtype != np.uint8:
        arr = (arr * 255).clip(0,255).astype(np.uint8)

    # Validate the current condition before continuing.
    if arr.ndim == 3 and arr.shape[-1] == 1:
        arr = arr.squeeze(axis=-1)
    # Validate the current condition before continuing.
    original_channels = arr.shape[2] if arr.ndim == 3 else 1
    pil_original = Image.fromarray(arr)
    # Validate the current condition before continuing.
    if original_channels == 1 and pil_original.mode != 'L':
        pil_original = pil_original.convert('L')
    elif original_channels == 3 and pil_original.mode != 'RGB':
        pil_original = pil_original.convert('RGB')
    width, height = pil_original.size
    img_bytes = pil_original.tobytes()

    # Describe the next operation.
    pad_len = 16 - (len(img_bytes) % 16)
    if pad_len != 16:
        img_bytes += bytes([pad_len]) * pad_len
    else:
        img_bytes += bytes([16]) * 16
        pad_len = 16

    salt = os.urandom(16)
    iv = os.urandom(16)
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(img_bytes) + encryptor.finalize()

    # Describe the next operation.
    meta = struct.pack('>IIBBB16s16s', width, height, original_channels, pad_len, 0, salt, iv)
    total_bytes = meta + ciphertext

    # Validate the current condition before continuing.
    if original_channels == 1:
        noise_mode = 'L'
        bytes_per_pixel = 1
    else:
        noise_mode = 'RGB'
        bytes_per_pixel = 3

    # Describe the next operation.
    pixel_needed = (len(total_bytes) + bytes_per_pixel - 1) // bytes_per_pixel
    noise_width = int(np.ceil(np.sqrt(pixel_needed)))
    noise_height = (pixel_needed + noise_width - 1) // noise_width

    # Describe the next operation.
    noise_img = Image.new(noise_mode, (noise_width, noise_height))
    total_pixel_bytes = noise_width * noise_height * bytes_per_pixel
    data = total_bytes + b'\x00' * (total_pixel_bytes - len(total_bytes))
    noise_img.frombytes(data)

    # Describe the next operation.
    return noise_img, (width, height, original_channels)


def decrypt_image_from_noise_image(noise_img: Image.Image, password: str) -> torch.Tensor:
    # if noise_img.mode != 'RGB':
    #     noise_img = noise_img.convert('RGB')
    img_bytes = noise_img.tobytes()

    if len(img_bytes) < 43:
        raise ValueError(f"Image too small: {len(img_bytes)} bytes, need at least 43")

    # Describe the next operation.
    meta = img_bytes[:43]
    width, height, channels, pad_len, _ = struct.unpack('>IIBBB', meta[:11])
    salt = meta[11:27]
    iv = meta[27:43]

    # Validate the current condition before continuing.
    original_img_bytes_len = width * height * (3 if channels == 3 else 1)
    # Process the trigger data for the cryptographic workflow.
    cipher_len = original_img_bytes_len + pad_len

    # Process the trigger data for the cryptographic workflow.
    ciphertext = img_bytes[43:43 + cipher_len]

    # Process the trigger data for the cryptographic workflow.
    key = derive_key(password, salt)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded = decryptor.update(ciphertext) + decryptor.finalize()

    # Apply the decryption step.
    plaintext = padded[:-pad_len]

    # Apply the decryption step.
    if len(plaintext) != original_img_bytes_len:
        raise ValueError(f"Decrypted data length mismatch: got {len(plaintext)}, expected {original_img_bytes_len}")

    # Validate the current condition before continuing.
    if channels == 1:
        recovered_img = Image.frombytes('L', (width, height), plaintext)
    else:
        recovered_img = Image.frombytes('RGB', (width, height), plaintext)

    # Convert the data to the required tensor shape.
    img_tensor = torch.from_numpy(np.array(recovered_img)).float() / 255.0
    if img_tensor.dim() == 2:
        img_tensor = img_tensor.unsqueeze(0)
    else:
        img_tensor = img_tensor.permute(2, 0, 1)
    return img_tensor
