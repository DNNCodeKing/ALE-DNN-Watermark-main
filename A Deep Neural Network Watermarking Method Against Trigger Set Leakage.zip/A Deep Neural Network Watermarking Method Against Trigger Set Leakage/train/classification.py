import os.path
import random
from pprint import pprint
import sys
import hashlib
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import seaborn as sns

import torch.nn as nn
import torch.optim as optim
import torchvision

from models.resnet import ResNet18, ResNet34, ResNet50, NaiveCNN, MoreNaiveCNN
from models.mobilenetv2 import MobileNetV2
from models.vgg import VGG
from models.watermark import Key
from models.senet import SENet18
from models.resnet_imagenet import imagenet_get_model
import torch.backends.cudnn as cudnn
import json
import torch.utils.data as data

from .attack import weight_prune, quantization, re_initializer_layer
from .utils import append_history, Logger
from .trainer import *
from .crypto_utils import *
from datasets.dataloader import *
from datasets.dataset import PseudoLabelDataset


class TriggerKey(nn.Module):
    def __init__(self, images, targets):
        super().__init__()
        # Describe the next operation.
        self.images = nn.Parameter(images, requires_grad=False)
        # Describe the next operation.
        self.register_buffer('targets', targets)


class Classifier:
    def __init__(self, args):
        self.args = args
        self._set_device(args)
        if args.action != 'evaluate':
            self._set_log()
        self.prepare_dataset()

        #=================AES========================
        for attr in ['trigger_plain_dir', 'encrypted_output_dir', 'encrypted_input_dir',
                     'decrypted_output_dir', 'trigger_encrypt_key', 'trigger_decrypt_key',
                     'save_encrypted_keypt', 'encrypt_as_noise_image', 'encrypted_trigger_path']:
            if not hasattr(args, attr):
                setattr(args, attr, None)

        self.net = self.build_model()
        self.optimizer, self.scheduler = self.build_optimizer(self.net)

    def train(self):
        self.start = time.time()
        self._train_model()
        end = time.time()
        print('Total time:%.4f min' % ((end - self.start) / 60))


    def evaluate(self):
        assert self.args.checkpoint_path is not None, "To test a model, provide the model path"

        checkpoint = torch.load(self.args.checkpoint_path)
        self.net.load_state_dict(checkpoint['net'])
        self._evaluate()  # Describe the next operation.

        # Describe the next operation.
        key = None

        # Validate the current condition before continuing.
        if hasattr(self.args, 'noise_trigger_path') and self.args.noise_trigger_path and os.path.exists(
                self.args.noise_trigger_path):
            noise_data = torch.load(self.args.noise_trigger_path, map_location=self.device, weights_only=False)
            if isinstance(noise_data, dict) and 'images' in noise_data and 'targets' in noise_data:
                # Describe the next operation.
                class SimpleTrigger:
                    pass

                key = SimpleTrigger()
                key.images = noise_data['images']
                key.targets = noise_data['targets']
                print(f"Loaded noise trigger from {self.args.noise_trigger_path}")
            else:
                print(f"Warning: {self.args.noise_trigger_path} format invalid")

        # Apply the encryption step.
        elif hasattr(self.args, 'encrypted_trigger_path') and self.args.encrypted_trigger_path and hasattr(self.args,                                                                                                          'trigger_decrypt_key') and self.args.trigger_decrypt_key:
            try:
                with open(self.args.encrypted_trigger_path, 'rb') as f:
                    encrypted_data = f.read()
                key = decrypt_trigger_object(encrypted_data, self.args.trigger_decrypt_key)
                key = key.to(self.device)
                print(f"Loaded and decrypted trigger from {self.args.encrypted_trigger_path}")
            except Exception as e:
                print(f"Failed to load encrypted trigger: {e}")

        # Validate the current condition before continuing.
        else:
            dirname = os.path.dirname(self.args.checkpoint_path)
            trigger_path = os.path.join(dirname, 'key.pt')
            if os.path.exists(trigger_path):
                key = torch.load(trigger_path, map_location=self.device, weights_only=False)
                print(f"Loaded plain trigger from {trigger_path}")

        if key is not None:
            self._evaluate_on_trigger(key)  # Validate the current condition before continuing.
        else:
            print("No trigger found, skip traditional watermark evaluation.")
    def prepare_dataset(self):
        self.trainloader, self.testloader, self.num_classes = get_dataloader(self.args.dataset, self.args.batch_size,
                                                                             data_path=self.args.data_path)

    def build_model(self):
        if 'VGG' in self.args.arch.upper():
            assert self.args.arch.upper() in ['VGG11', 'VGG13', 'VGG16', 'VGG19']
            net = VGG(self.args.arch.upper(), self.num_classes).to(self.device)
        elif 'senet' in self.args.arch:
            net = SENet18(self.num_classes).to(self.device)
        elif 'imgnet' in self.args.arch:
            net = imagenet_get_model('res34').to(self.device)
        else:
            Network = {'resnet18': ResNet18,
                       'resnet34': ResNet34,
                       'resnet50': ResNet50,
                       'vanilla': NaiveCNN,
                       'simple': MoreNaiveCNN,
                       'mobile': MobileNetV2}[self.args.arch]
            net = Network(self.num_classes).to(self.device)
        return net

    def build_optimizer(self, net):
        if self.args.dataset in ['cifar10', 'cifar100', 'fashion', 'mnist','gtsrb','tiny-imagenet-200','imagenet32']:
            optimizer = optim.Adam(net.parameters(), lr=self.args.lr, betas=(0.9, 0.99), eps=1e-5)
            scheduler = None

        else:
            optimizer = optim.SGD(net.parameters(), lr=self.args.lr, weight_decay=1e-4)
            scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=200)

        return optimizer, scheduler

    def _encrypt_trigger_files(self):

        src_dir = self.args.trigger_plain_dir
        out_dir = self.args.encrypted_output_dir
        password = self.args.trigger_encrypt_key
        as_noise = getattr(self.args, 'encrypt_as_noise_image', True)

        if not src_dir or not out_dir or not password:
            raise ValueError("Must provide trigger_plain_dir, encrypted_output_dir, trigger_encrypt_key")

        os.makedirs(out_dir, exist_ok=True)

        # Prepare the required output path.
        key_path = os.path.join(src_dir, 'key.pt')
        if not os.path.exists(key_path):
            raise FileNotFoundError(f"key.pt not found in {src_dir}")
        key = torch.load(key_path, map_location='cpu', weights_only=False)
        original_images = key.images  # Describe the next operation.
        targets = key.targets  # Convert the data to the required tensor shape.

        # Convert the data to the required tensor shape.
        noise_tensors = []
        for idx, img_tensor in enumerate(original_images):
            if as_noise:
                # Apply the encryption step.
                noise_img, _ = encrypt_image_to_noise_image(img_tensor, password)
                # Convert the data to the required tensor shape.
                noise_tensor = transforms.ToTensor()(noise_img)
            else:
                # Apply the encryption step.
                enc_data = encrypt_image(img_tensor, password)
                # Describe the next operation.
                # Describe the next operation.
                raise NotImplementedError("Binary mode not supported for generating key.pt; use noise image mode.")
            noise_tensors.append(noise_tensor)

        # Convert the data to the required tensor shape.
        noise_images = torch.stack(noise_tensors)
        encrypted_key = TriggerKey(noise_images, targets)
        # Save the generated output.
        torch.save(encrypted_key, os.path.join(out_dir, 'key.pt'))

        # Validate the current condition before continuing.
        if as_noise:
            img_dir = os.path.join(out_dir, 'noise_images')
            os.makedirs(img_dir, exist_ok=True)
            for idx, noise_tensor in enumerate(noise_tensors):
                # Convert the data to the required tensor shape.
                noise_pil = transforms.ToPILImage()(noise_tensor)
                noise_pil.save(os.path.join(img_dir, f'noise_{idx:04d}.png'))

        print(f"Encrypted triggers saved to {out_dir}")
        print(f"  - Noise images: {out_dir}/noise_images/")
        print(f"  - key.pt (contains noise image tensors) saved to {out_dir}/key.pt")

    def _decrypt_trigger_files(self):

        enc_path = self.args.encrypted_input_dir
        out_dir = self.args.decrypted_output_dir
        password = self.args.trigger_decrypt_key
        as_noise = getattr(self.args, 'encrypt_as_noise_image', True)

        if not enc_path or not out_dir or not password:
            raise ValueError("Must provide encrypted_input_dir, decrypted_output_dir, trigger_decrypt_key")

        os.makedirs(out_dir, exist_ok=True)

        # Validate the current condition before continuing.
        if os.path.isfile(enc_path) and enc_path.endswith('.pt'):
            print(f"Decrypting key.pt: {enc_path}")
            with open(enc_path, 'rb') as f:
                enc_data = f.read()
            key = decrypt_trigger_object(enc_data, password)

            # Save the generated output.
            torch.save(key, os.path.join(out_dir, 'key.pt'))
            # Prepare the required output path.
            png_dir = os.path.join(out_dir, 'examples')
            os.makedirs(png_dir, exist_ok=True)
            for idx, img_tensor in enumerate(key.images):
                img_pil = transforms.ToPILImage()(img_tensor.clamp(0, 1))
                img_pil.save(os.path.join(png_dir, f'{idx:04d}.png'))
            print(f"Decrypted key.pt and PNGs saved to {out_dir}")
            return

        # Validate the current condition before continuing.
        # Validate the current condition before continuing.
        if as_noise:
            img_dir = os.path.join(enc_path, 'noise_images')
            if not os.path.isdir(img_dir):
                img_dir = enc_path  # Validate the current condition before continuing.
            enc_files = sorted([f for f in os.listdir(img_dir) if f.startswith('noise_') and f.endswith('.png')])
            decrypt_func = lambda path: decrypt_image_from_noise_image(Image.open(path), password)
        else:
            img_dir = enc_path
            enc_files = sorted([f for f in os.listdir(img_dir) if f.startswith('img_') and f.endswith('.enc')])
            decrypt_func = lambda path: decrypt_image(open(path, 'rb').read(), password)

        if not enc_files:
            raise RuntimeError(f"No encrypted image files found in {img_dir}")

        images = []
        for fname in enc_files:
            img_tensor = decrypt_func(os.path.join(img_dir, fname))
            images.append(img_tensor)

        # Prepare the required output path.
        label_path = os.path.join(enc_path, 'labels.txt')
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                labels = list(map(int, f.read().split(',')))
        else:
            key_target = getattr(self.args, 'key_target', None)
            if key_target is None:
                raise ValueError("No labels.txt found and key_target not provided. Cannot determine labels.")
            labels = [key_target] * len(images)

        # Prepare the required output path.
        png_dir = os.path.join(out_dir, 'examples')
        os.makedirs(png_dir, exist_ok=True)
        for idx, img_tensor in enumerate(images):
            img_pil = transforms.ToPILImage()(img_tensor.clamp(0, 1))
            img_pil.save(os.path.join(png_dir, f'{idx:04d}.png'))

        decrypted_key = TriggerKey(torch.stack(images), torch.tensor(labels))
        torch.save(decrypted_key, os.path.join(out_dir, 'key.pt'))
        print(f"Decrypted images and key.pt saved to {out_dir}")

    def _train_model(self):
        if self.args.action == 'clean':
            self._train_clean()
        elif self.args.action == 'watermark':
            self._train_watermark()
        elif self.args.action == 'eval_trigger':
            self._eval_trigger()
        elif self.args.action == 'coupling_eval':
            self._coupling_eval()
        elif self.args.action == 'encrypt_trigger':
            self._encrypt_trigger_files()
        elif self.args.action == 'decrypt_trigger':
            self._decrypt_trigger_files()
        else:
            self._attack()

    def _train_clean(self):
        criterion = nn.CrossEntropyLoss()
        start_epoch = 0
        best_acc = 0.

        if self.args.checkpoint_path is not None:
            checkpoint = torch.load(self.args.checkpoint_path)
            best_acc = checkpoint['acc']
            start_epoch = checkpoint['epoch'] + 1
            self.net.load_state_dict(checkpoint['net'])

        for epoch in range(start_epoch, self.args.epochs):
            print('\nEpoch: %d' % epoch)

            train_metrics = train(self.net, criterion, self.optimizer, self.trainloader, self.device)

            # Describe the next operation.
            print(
                f"Train Loss: {train_metrics['loss']:.4f} | Train Acc: {train_metrics['acc']:.4f} | Time: {train_metrics['time']:.2f}s")

            if self.scheduler is not None:
                self.scheduler.step()

            # Evaluate the model and collect metrics.
            valid_metrics = self._evaluate(verbose=True)

            # Evaluate the model and collect metrics.

            # Record training, validation, and watermark metrics for this epoch.
            metrics = {'epoch': epoch}
            for k in train_metrics: metrics[f'train_{k}'] = train_metrics[k]
            for k in valid_metrics: metrics[f'valid_{k}'] = valid_metrics[k]

            best_acc = self._log_metrics_and_models(metrics, epoch == start_epoch, epoch, best_acc)

    def _build_trigger_set(self):
        channels = {'cifar10': 3, 'cifar100': 3, 'gtsrb': 3, 'imagenet32': 3, 'fashion': 1, 'mnist': 1,}[self.args.dataset]  # Describe the next operation.
        key = Key(self.args.key_num, self.args.key_target, channels, self.device, self.args.data_path).to(self.device)
        return key

    def _train_watermark(self):
        positive_shadow = self.build_model()
        shadow_optimizer, shadow_scheduler = self.build_optimizer(positive_shadow)

        negative_shadow = self.build_model()
        assert self.args.clean_model_path is not None, "Provide a clean model as the negative shadow model"
        negative_shadow.load_state_dict(torch.load(self.args.clean_model_path)['net'])

        key = self._build_trigger_set()
        k_optimizer = optim.Adam(key.parameters(), lr=self.args.wm_lr)

        # Update the model parameters during training.
        # if self.args.from_pretrained:
        #     self.net.load_state_dict(torch.load(self.args.clean_model_path)['net'])
        #     positive_shadow.load_state_dict(torch.load(self.args.clean_model_path)['net'])

        # Update the model parameters during training.
        if self.args.from_pretrained:
            # Update the model parameters during training.
            if self.args.host_pretrained_path is not None:
                host_path = self.args.host_pretrained_path
            else:
                host_path = self.args.clean_model_path
            self.net.load_state_dict(torch.load(host_path)['net'])

            # Update the model parameters during training.
            if self.args.positive_pretrained_path is not None:
                pos_path = self.args.positive_pretrained_path
            else:
                pos_path = self.args.clean_model_path
            positive_shadow.load_state_dict(torch.load(pos_path)['net'])

        # Update the model parameters during training.
        negative_path = self.args.negative_pretrained_path if self.args.negative_pretrained_path is not None else self.args.clean_model_path
        negative_shadow.load_state_dict(torch.load(negative_path)['net'])

        # dataloader for shadow model (no augmentation)
        dataloader, _, _ = get_dataloader(self.args.dataset, self.args.batch_size, augment=False)
        shadow_trainloader, _, _ = get_dataloader(self.args.dataset, self.args.batch_size)

        criterion = nn.CrossEntropyLoss()
        start_epoch = 0
        best_acc = 0.

        for epoch in range(start_epoch, self.args.epochs):
            print('\nEpoch: %d' % epoch)

            # Train the host model with the traditional watermark trigger set.
            train_metrics = train_on_watermark(
                self.net, criterion, self.optimizer, self.trainloader, key, self.device
            )

            if self.scheduler is not None:
                self.scheduler.step()

            # Generate pseudo-labels with the host model for the positive shadow model.
            self.net.eval()
            labels = [self.net(inputs.to(self.device)).max(1)[1].cpu() for inputs, _ in dataloader]
            pseudo_labels = torch.cat(labels).long()

            if hasattr(shadow_trainloader.dataset, 'targets') and shadow_trainloader.dataset.targets is not None:
                if self.args.dataset == 'fashion':
                    shadow_trainloader.dataset.targets = pseudo_labels
                else:
                    shadow_trainloader.dataset.targets = [t.item() for t in pseudo_labels]
            else:
                wrapped_dataset = PseudoLabelDataset(shadow_trainloader.dataset, pseudo_labels)
                shadow_trainloader = torch.utils.data.DataLoader(
                    wrapped_dataset,
                    batch_size=self.args.batch_size,
                    shuffle=True,
                    num_workers=4,
                    pin_memory=True
                )

            train_metrics_s = train(
                positive_shadow, criterion, shadow_optimizer, shadow_trainloader, self.device
            )
            if shadow_scheduler is not None:
                shadow_scheduler.step()

            valid_metrics = self._evaluate(verbose=False)
            valid_metrics_pos = self._evaluate(model=positive_shadow, verbose=False)
            print(f"Test acc | Host net: {valid_metrics['acc']:.4f}")
            print(f"Test acc | Positive shadow net: {valid_metrics_pos['acc']:.4f}")

            wm_metrics = self._evaluate_on_trigger(key, model=self.net, verbose=False)
            print(f"Trigger set acc (traditional) | Host net: {wm_metrics['acc']:.4f}")

            if epoch >= self.args.epochs - self.args.wm_epoch:
                key_loss = optimize_key(self.net, positive_shadow, negative_shadow,
                                        criterion, key, k_optimizer, self.args.wm_it)
                wm_metrics_pos = self._evaluate_on_trigger(key, model=positive_shadow, verbose=False)
                wm_metrics_neg = self._evaluate_on_trigger(key, model=negative_shadow, verbose=False)
                print(f"Trigger set acc (traditional) | Positive shadow net: {wm_metrics_pos['acc']:.4f}")
                print(f"Trigger set acc (traditional) | Negative shadow net: {wm_metrics_neg['acc']:.4f}")

            # Record training, validation, and watermark metrics for this epoch.
            metrics = {'epoch': epoch}
            for k in train_metrics: metrics[f'train_{k}'] = train_metrics[k]
            for k in valid_metrics: metrics[f'valid_{k}'] = valid_metrics[k]
            for k in wm_metrics: metrics[f'wm_{k}'] = wm_metrics[k]

            best_acc = self._log_metrics_and_models(metrics, epoch == start_epoch, epoch, best_acc)

        # Describe the next operation.
        prediction_on_trigger = test_on_watermark(self.net, criterion, key)['prediction']
        select = prediction_on_trigger.eq(key.targets)

        prediction_on_trigger = test_on_watermark(positive_shadow, criterion, key)['prediction']
        select = prediction_on_trigger.eq(key.targets) & select

        prediction_on_trigger = test_on_watermark(negative_shadow, criterion, key)['prediction']
        select = prediction_on_trigger.not_equal(key.targets) & select

        print('Selected trigger set size', select.sum().item())

        key.images.data = key.images.data[select]
        key.targets = key.targets[select]
        torch.save(key, os.path.join(self.log_dir, 'key.pt'))

        if self.args.save_trigger:
            os.makedirs(os.path.join(self.log_dir, 'trigger', 'examples'), exist_ok=True)
            torchvision.utils.save_image(key.images[:20], os.path.join(self.log_dir, 'trigger', 'grid.png'),
                                         normalize=True, nrow=5)
            for i, image in enumerate(key.images.data):
                img = torch.clamp(image, min=0.0, max=1.0)
                img = img.permute(1, 2, 0).cpu().numpy()
                img = np.squeeze(img)
                img = (img * 255.).astype(np.uint8)
                img = Image.fromarray(img)
                img.save(os.path.join(self.log_dir, 'trigger', 'examples', f'{i:04}.png'))

    def _attack(self):
        """attack a watermarked model"""
        assert self.args.victim_path is not None, "To attack a model, provide the victim model path"
        if self.args.dataset == 'fashion':
            victim = NaiveCNN(10).to(self.device)
        elif self.args.dataset == 'cifar10':
            victim = ResNet18(10).to(self.device)
        elif self.args.dataset == 'gtsrb':
            victim = ResNet18(43).to(self.device)
        elif self.args.dataset == 'tiny-imagenet-200':
            victim = ResNet18(200).to(self.device)
        else:
            victim = ResNet18(100).to(self.device)
        victim.load_state_dict(torch.load(self.args.victim_path)['net'])

        # Describe the next operation.
        key = None

        # Validate the current condition before continuing.
        if hasattr(self.args, 'noise_trigger_path') and self.args.noise_trigger_path and os.path.exists(
                self.args.noise_trigger_path):
            noise_data = torch.load(self.args.noise_trigger_path, map_location=self.device, weights_only=False)
            if isinstance(noise_data, dict) and 'images' in noise_data and 'targets' in noise_data:
                class SimpleTrigger:
                    pass

                key = SimpleTrigger()
                key.images = noise_data['images']
                key.targets = noise_data['targets']
                print(f"Loaded noise trigger from {self.args.noise_trigger_path}")
            else:
                raise RuntimeError("Invalid noise trigger file")

        # Apply the encryption step.
        elif hasattr(self.args, 'encrypted_trigger_path') and self.args.encrypted_trigger_path and hasattr(self.args,
                                                                                                           'trigger_decrypt_key') and self.args.trigger_decrypt_key:
            try:
                with open(self.args.encrypted_trigger_path, 'rb') as f:
                    encrypted_data = f.read()
                key = decrypt_trigger_object(encrypted_data, self.args.trigger_decrypt_key)
                key = key.to(self.device)
                print(f"Decrypted trigger from {self.args.encrypted_trigger_path}")
            except Exception as e:
                print(f"Failed to load encrypted trigger: {e}")

        # Validate the current condition before continuing.
        else:
            key_path = os.path.join(os.path.dirname(self.args.victim_path), 'key.pt')
            if os.path.exists(key_path):
                key = torch.load(key_path, map_location=self.device, weights_only=False).to(self.device)
                print(f"Loaded plain trigger from {key_path}")

        if key is None:
            raise RuntimeError("No trigger found (neither noise, encrypted, nor plain). Cannot perform attack.")

        self.key = key

        valid_metrics = self._evaluate(model=victim, verbose=False)
        print(f"Test acc | Victim net: {valid_metrics['acc']:.4f}")
        wm_metrics = self._evaluate_on_trigger(self.key, model=victim, verbose=False)
        print(f"Trigger set acc | Victim net: {wm_metrics['acc']:.4f}")

        if self.args.attack_type == 'prune':
            self.__prune_attack(victim)
        elif self.args.attack_type == 'quantization':
            self.__weight_quantization(victim)
        elif self.args.attack_type in ['ftll', 'ftal', 'rtll', 'rtal']:
            self.__fine_tune(victim)
        else:
            self.__model_extract(victim)

    def _set_device(self, args):
        os.environ['CUDA_VISIBLE_DEVICES'] = args.gpu
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        if args.seed is None:
            args.seed = random.randint(0, 2023)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed(args.seed)
        np.random.seed(args.seed)
        random.seed(args.seed)
        torch.backends.cudnn.benchmark = True

    def _set_log(self):
        if self.args.action != 'attack':
            # path to a clean / watermarked model
            log_dir = os.path.join(self.args.log_dir, self.args.dataset, self.args.action)
            log_dir = os.path.join(log_dir, time.strftime("%m-%d-%H-%M-", time.localtime()) + self.args.runname)
        else:
            # path to the attacked model
            log_dir = os.path.split(self.args.victim_path)[0]  # victim model's dir
            log_dir = os.path.join(log_dir, 'attack', self.args.attack_type, self.args.runname)
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)

        self.log_file = os.path.join(log_dir, 'log.txt')
        self.config_file = os.path.join(log_dir, 'conf.json')
        self.history_file = os.path.join(log_dir, 'history.csv')

        json.dump(vars(self.args), open(self.config_file, 'w'), indent=4)
        pprint(vars(self.args))

        sys.stdout = Logger(filename=self.log_file, stream=sys.stdout)

    def _evaluate(self, model=None, verbose=True):
        criterion = nn.CrossEntropyLoss()
        if model is None:
            model = self.net
        valid_metrics = test(model, criterion, self.testloader, self.device)
        if verbose:
            print('Test acc: %.4f, test loss: %.4f' % (valid_metrics['acc'], valid_metrics['loss']))
        return valid_metrics

    def _evaluate_on_trigger(self, key, model=None, verbose=True, return_pred=False):
        """
        评估传统触发集（key）在指定模型上的准确率。
        返回包含 'acc', 'loss', 'time', 以及可选的 'prediction' 的字典。
        """
        criterion = nn.CrossEntropyLoss()
        if model is None:
            model = self.net
        valid_metrics = test_on_watermark(model, criterion, key)
        if verbose:
            print('Trigger set acc: %.4f' % (valid_metrics['acc']))
        if not return_pred:
            del valid_metrics['prediction']
        return valid_metrics

    #check clean model
    def _eval_trigger(self):
        """Documentation.，Documentation. check Documentation."""
        import json
        import time
        import os

        assert self.args.model_path is not None, "Please provide model_path"
        assert self.args.trigger_path is not None, "Please provide trigger_path"

        # Prepare the required output path.
        trigger_dir = os.path.dirname(self.args.trigger_path)
        check_base = os.path.join(trigger_dir, 'check_clean_on_trigger')
        os.makedirs(check_base, exist_ok=True)

        timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        out_dir = os.path.join(check_base, timestamp)
        os.makedirs(out_dir, exist_ok=True)

        # Prepare the required output path.
        conf_path = os.path.join(out_dir, 'conf.json')
        json.dump(vars(self.args), open(conf_path, 'w'), indent=4)
        print(f"Configuration saved to {conf_path}")

        # Prepare the required output path.
        log_file = os.path.join(out_dir, 'log.txt')
        sys.stdout = Logger(filename=log_file, stream=sys.stdout)

        print("=== Evaluating trigger set on clean model ===")
        print(f"Model: {self.args.model_path}")
        print(f"Trigger: {self.args.trigger_path}")

        # Validate the current condition before continuing.
        if not os.path.exists(self.args.model_path):
            raise FileNotFoundError(f"Model file not found: {self.args.model_path}")
        checkpoint = torch.load(self.args.model_path, map_location=self.device)
        self.net.load_state_dict(checkpoint['net'])

        # Validate the current condition before continuing.
        if not os.path.exists(self.args.trigger_path):
            raise FileNotFoundError(f"Trigger file not found: {self.args.trigger_path}")
        # Load the required input data.
        key = torch.load(self.args.trigger_path, map_location=self.device, weights_only=False)

        # Describe the next operation.
        criterion = nn.CrossEntropyLoss()
        metrics = test_on_watermark(self.net, criterion, key)  # Evaluate the model and collect metrics.
        acc = metrics['acc']
        correct = int(acc * len(key.images))
        total = len(key.images)
        print(f"Trigger set accuracy: {acc:.4f} (correct: {correct}/{total})")

        # Prepare the required output path.
        # Prepare the required output path.
        result_file = os.path.join(out_dir, 'trigger_eval.json')
        result = {
            'model_path': self.args.model_path,
            'trigger_path': self.args.trigger_path,
            'accuracy': acc,
            'correct': correct,
            'total': total,
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S")
        }
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=4)
        print(f"Results saved to {result_file}")

    def _log_metrics_and_models(self, metrics, firstrow, epoch, best_acc):
        append_history(self.history_file, metrics, firstrow)

        state = {
            'net': self.net.state_dict(),
            'acc': metrics['valid_acc'],
            'epoch': epoch
        }

        if self.args.save_interval and (epoch + 1) % self.args.save_interval == 0:
            torch.save(state, os.path.join(self.log_dir, f'epoch-{epoch}.pth'))

        if best_acc < metrics['valid_acc']:
            print(f'Found best at epoch {epoch}\n')
            best_acc = metrics['valid_acc']
            torch.save(state, os.path.join(self.log_dir, 'best.pt'))

        torch.save(state, os.path.join(self.log_dir, 'last.pt'))

        return best_acc

    def __model_extract(self, victim):
        device = self.device
        key = self.key

        criterion = nn.CrossEntropyLoss()
        start_epoch = 0
        best_acc = 0.

        # cross structure retraining
        if self.args.attack_type == 'cross':
            self.net = self.build_model()
            self.optimizer = optim.SGD(self.net.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-4)
            self.scheduler = optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=[20, 40], gamma=0.1)

        # distilling
        if self.args.attack_type == 'distill':
            self.args.extract_soft = 1
            self.args.arch = {'cifar10': 'mobile', 'cifar100': 'mobile', 'fashion': 'simple', 'gtsrb': 'mobile','tiny-imagenet-200': 'mobile','imagenet32': 'mobile'}[self.args.dataset]  # Describe the next operation.
            self.net = self.build_model()
            self.optimizer = optim.Adam(self.net.parameters(), lr=0.001, betas=(0.9, 0.99), eps=1e-5)

        # knockoff nets
        use_transfer = True if self.args.attack_type == 'knockoff' else False
        transfer_set = {'cifar10': 'cifar100', 'cifar100': 'imagenet32', 'fashion': 'graycifar10', 'gtsrb': 'imagenet32','tiny-imagenet-200': 'imagenet32','imagenet32':'cifar100'}[self.args.dataset]  # Prepare the dataset or data loader.

        # attacker's dataset
        extracted_loader, _, _ = get_dataloader(transfer_set if use_transfer else self.args.dataset,
                                                self.args.batch_size, augment=False)
        print("Attacker's training set size:", len(extracted_loader.dataset))
        victim.eval()

        if self.args.extract_soft or use_transfer:
            # using probability
            with torch.no_grad():
                extracted_prob = [torch.softmax(victim(inputs.to(device)), dim=1).data.cpu() for inputs, _ in extracted_loader]
                soft_label = torch.cat(extracted_prob, dim=0)
            extracted_loader, _, _ = get_soft_label_dataloader(soft_label,
                                                               transfer_set if use_transfer else self.args.dataset)
        else:
            # Describe the next operation.
            # using hard label
            with torch.no_grad():
                extracted_label = [victim(inputs.to(device)).max(1)[1].data.cpu() for inputs, _ in extracted_loader]
                extracted_label = torch.cat(extracted_label).long()

            extracted_loader, _, _ = get_dataloader(transfer_set if use_transfer else self.args.dataset,
                                                    self.args.batch_size)

            # Prepare the dataset or data loader.
            if hasattr(extracted_loader.dataset, 'targets') and extracted_loader.dataset.targets is not None:
                # Prepare the dataset or data loader.
                if isinstance(extracted_loader.dataset.targets, torch.Tensor):
                    extracted_loader.dataset.targets = extracted_label
                else:
                    extracted_loader.dataset.targets = [t.item() for t in extracted_label]
            else:
                # Prepare the dataset or data loader.
                wrapped_dataset = PseudoLabelDataset(extracted_loader.dataset, extracted_label)
                extracted_loader = torch.utils.data.DataLoader(
                    wrapped_dataset,
                    batch_size=self.args.batch_size,
                    shuffle=True,
                    num_workers=4,
                    pin_memory=True
                )

        for epoch in range(start_epoch, self.args.epochs):
            print('\nEpoch: %d' % epoch)
            if self.args.extract_soft or use_transfer:
                train_metrics = train_by_soft_label(self.net, self.optimizer, extracted_loader, device,
                                                    self.args.attack_type == 'distill')
            else:
                train_metrics = train(self.net, criterion, self.optimizer, extracted_loader, self.device)

            valid_metrics = self._evaluate(verbose=False)
            print(f"Test acc | Surrogate net: {valid_metrics['acc']:.4f}")
            wm_metrics = self._evaluate_on_trigger(self.key, verbose=False)
            print(f"Trigger set acc | Surrogate net: {wm_metrics['acc']:.4f}")

            if self.scheduler is not None:
                self.scheduler.step()

            metrics = {'epoch': epoch}
            for k in train_metrics: metrics[f'train_{k}'] = train_metrics[k]
            for k in valid_metrics: metrics[f'valid_{k}'] = valid_metrics[k]
            for k in wm_metrics: metrics[f'wm_{k}'] = wm_metrics[k]

            best_acc = self._log_metrics_and_models(metrics, epoch == start_epoch, epoch, best_acc)

    def __prune_attack(self, victim):
        key = self.key

        print('Pruning the model...')
        for perc in [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]:
            print(f'\nPruning rate: {perc}%')
            pruned_model = weight_prune(victim, perc)
            metrics = self._evaluate(model=pruned_model)
            wm_metrics = self._evaluate_on_trigger(key, model=pruned_model)

            # save the pruned model
            if perc == 60:
                state = {
                    'net': pruned_model.state_dict(),
                    'acc': metrics['acc'],
                    'epoch': 0,
                }
                torch.save(state, os.path.join(self.log_dir, 'last.pt'))

    def __weight_quantization(self, victim, bits=4.0):
        key = self.key

        for name, param in victim.named_parameters():
            quantization(param, bits=bits)

        print(f'Quantifying the model with {bits} bits...')
        test_acc = self._evaluate(model=victim, verbose=True)['acc']
        wm_acc = self._evaluate_on_trigger(key, model=victim, verbose=True)['acc']
        state = {
            'net': victim.state_dict(),
            'acc': test_acc,
            'epoch': 0,
        }

    # Describe the next operation.
    def __fine_tune(self, victim):
        self.net = victim
        key = self.key

        # Update the model parameters during training.
        training_set_size = len(self.trainloader.dataset)
        perc = 0.2
        select_index = random.sample(list(range(training_set_size)), int(training_set_size * perc))

        # Describe the next operation.
        from torch.utils.data import Subset
        subset_dataset = Subset(self.trainloader.dataset, select_index)
        from torch.utils.data import DataLoader
        self.trainloader = DataLoader(
            subset_dataset,
            batch_size=self.args.batch_size,
            shuffle=True,
            num_workers=4
        )

        print(f'Attacker training set size: {len(subset_dataset)}')

        # Validate the current condition before continuing.
        if self.args.attack_type == 'rtal':
            self.net, _ = re_initializer_layer(self.net, self.num_classes, self.device)
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=0.0005)
        else:
            # Update the model parameters during training.
            self.optimizer = torch.optim.Adam(self.net.parameters(), lr=0.0001)

        start_epoch = 0
        best_acc = 0.
        criterion = nn.CrossEntropyLoss()

        for epoch in range(start_epoch, self.args.epochs):
            print('\nEpoch: %d' % epoch)
            train_metrics = train(self.net, criterion, self.optimizer, self.trainloader, self.device)

            valid_metrics = self._evaluate(verbose=False)
            print('Test acc: %.4f, test loss: %.4f' % (valid_metrics['acc'], valid_metrics['loss']))

            wm_metrics = self._evaluate_on_trigger(key, verbose=False)
            print(f"Watermark acc: {wm_metrics['acc']:.6f}")

            metrics = {'epoch': epoch}
            for k in train_metrics: metrics[f'train_{k}'] = train_metrics[k]
            for k in valid_metrics: metrics[f'valid_{k}'] = valid_metrics[k]
            for k in wm_metrics: metrics[f'wm_{k}'] = wm_metrics[k]

            best_acc = self._log_metrics_and_models(metrics, epoch == start_epoch, epoch, best_acc)

