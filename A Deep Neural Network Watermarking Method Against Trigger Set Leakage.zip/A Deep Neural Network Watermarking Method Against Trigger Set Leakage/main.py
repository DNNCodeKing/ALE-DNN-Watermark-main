import argparse
from argparse import Namespace
import yaml
from train.classification import Classifier

def parse_args():
    parser = argparse.ArgumentParser(description="Parameters for running model watermarking experiments")

    parser.add_argument('--action', default='watermark', choices=['clean', 'watermark', 'attack', 'evaluate', 'eval_trigger',
                                                                  'coupling_eval',
                                                                  'encrypt_trigger', 'decrypt_trigger'],
                        help='watermark: train a watermarked model,\n'
                             'clean: train a clean model,\n'
                             'attack: attack a given model,\n'
                             'evaluate: test a given model\n'
                             'encrypt_trigger: encrypt existing trigger set\n'
                             'decrypt_trigger: decrypt encrypted trigger set')
    # parser.add_argument('--action', default='watermark',
    #                     choices=['clean', 'watermark', 'attack', 'evaluate', 'forge'],
    #                     help='forge: embed anti-forge watermark using hash chain')
    parser.add_argument('--dataset', default='fashion', help='Dataset used to train a model (default: fashion)')
    parser.add_argument('--batch_size', type=int, default=128,
                        help='batch size (default: 128)')
    parser.add_argument('--data_path', default='./data', help='Path to store all the relevant datasets (default: '
                                                              './data)')

    parser.add_argument('--arch', default='vanilla',
                        choices=['vanilla', 'resnet18', 'resnet34', 'resnet50', 'simple', 'mobile', 'VGG16', 'senet'],
                        help='Model architecture (default: vanilla)\n')

    parser.add_argument('--epochs', type=int, help='Training epochs')
    parser.add_argument('--lr', type=float, default=0.001, help='Learning rate')

    parser.add_argument('--gpu', default='0', type=str, help='GPU index')
    parser.add_argument('--seed', default=None, type=int, help='Seed for random')

    parser.add_argument('--log_dir', default='logs', help='Logging directory')
    parser.add_argument('--runname', default='', help='Name for an experiment')
    parser.add_argument('--save-interval', type=int, default=100, help='Save model interval')

    # evaluate a model, or resume from a model
    parser.add_argument('--checkpoint_path', help='Checkpoint path (example: xxx/xxx/last.pt)')

    # watermark
    parser.add_argument('--key_num', default=100, type=int, help='Trigger set size in training')
    parser.add_argument('--key_target', default=1, type=int, help='Target label')

    # watermark a pretrained model
    parser.add_argument('--clean_model_path', type=str, default=None, help='Path to the non-watermarked model')
    parser.add_argument('--host_pretrained_path', type=str, default=None,
                        help='Path to pretrained weights for host model (if None, use clean_model_path)')
    parser.add_argument('--positive_pretrained_path', type=str, default=None,
                        help='Path to pretrained weights for positive shadow model (if None, use clean_model_path)')
    parser.add_argument('--negative_pretrained_path', type=str, default=None,
                        help='Path to pretrained weights for negative shadow model (if None, use clean_model_path)')
    parser.add_argument('--from_pretrained', type=bool, default=True, help='Path to the non-watermarked model')
    parser.add_argument('--wm_lr', default=0.1, type=float, help='Learning rate for the trigger images')
    parser.add_argument('--wm_epoch', default=5, type=int, help='Epochs to optimize the trigger images')
    parser.add_argument('--save_trigger', action='store_true', help='Save the trigger set as png images')
    parser.add_argument('--wm_it', default=20, type=int, help='Iterations to optimize the trigger images')

    # attack a model
    parser.add_argument('--victim_path', default=None, help='Victim model path (example: xxx/xxx/last.pt)')
    parser.add_argument('--extract_soft', default=0, type=int, help='Model extraction with probability vectors')

    # retrain means hard label extraction
    parser.add_argument('--attack_type', default=None, choices=['retrain', 'distill', 'knockoff', 'cross',
                                                                'ftal', 'rtal', 'prune', 'quantization'],
                        type=str, help='Attack type')
    parser.add_argument('--config', type=str, default=None, help='Path to YAML configuration file')

    # Reversible AES trigger encryption.
    parser.add_argument('--trigger_plain_dir', type=str, default=None,
                        help='Directory containing plain trigger (key.pt and examples/*.png)')
    parser.add_argument('--encrypted_output_dir', type=str, default=None,
                        help='Directory to save encrypted files')
    parser.add_argument('--encrypted_input_dir', type=str, default=None,
                        help='Directory containing encrypted files (or a single key.pt file)')
    parser.add_argument('--decrypted_output_dir', type=str, default=None,
                        help='Directory to save decrypted plain files')
    parser.add_argument('--trigger_encrypt_key', type=str, default=None,
                        help='Password for encryption')
    parser.add_argument('--trigger_decrypt_key', type=str, default=None,
                        help='Password for decryption')
    parser.add_argument('--save_encrypted_keypt', action='store_true',
                        help='Also save encrypted whole key.pt (key.pt)')
    parser.add_argument('--encrypt_as_noise_image', action='store_true',
                        help='Encrypt triggers as noise PNG images instead of binary .enc files')
    parser.add_argument('--encrypted_trigger_path', type=str, default=None,
                        help='Path to encrypted key.pt file for direct evaluation/attack')
    parser.add_argument('--noise_trigger_path', type=str, default=None,
                        help='Path to key.pt (noise tensors) for direct evaluation/attack (simulating attacker)')

    # Evaluate a clean model on a trigger set.
    parser.add_argument('--model_path', type=str, default=None,
                        help='Path to the model checkpoint (e.g., last.pt) for eval_trigger')
    parser.add_argument('--trigger_path', type=str, default=None,
                        help='Path to the trigger set file (key.pt) for eval_trigger')

    args = parser.parse_args()

    if args.config:
        # Read the configuration file using UTF-8 encoding.
        with open(args.config, 'r', encoding='utf-8') as config_file:
            config_args = yaml.safe_load(config_file)
            for key, value in config_args.items():
                setattr(args, key, value)

    return args


if __name__ == '__main__':
    args = parse_args()
    classifier = Classifier(args)
    if args.action != 'evaluate':
        classifier.train()
    else:
        classifier.evaluate()
