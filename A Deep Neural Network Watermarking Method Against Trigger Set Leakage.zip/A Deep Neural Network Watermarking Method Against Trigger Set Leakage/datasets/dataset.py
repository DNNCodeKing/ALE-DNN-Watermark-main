import numpy as np
import torch
from torchvision import datasets, transforms
import torch.utils.data as data
from PIL import Image
import pickle
from torch.utils.data import Dataset
# import tensorflow as tf
# import tensorflow_datasets as tfds
from PIL import Image
import pandas as pd
from torchvision.datasets.utils import download_url, extract_archive
import os


class SubMNIST(datasets.MNIST):
    def __init__(self, root, train, download, transform=None, source=0):
        super(SubMNIST, self).__init__(root=root, train=train, download=download, transform=transform)
        data = self.data[self.targets == source]
        targets = self.targets[self.targets == source]
        self.data = data
        self.targets = targets


class SubSVHN(datasets.SVHN):
    def __init__(self, root, split, download, transform=None, source=0):
        super(SubSVHN, self).__init__(root=root, split=split, download=download, transform=transform)
        data = self.data[self.labels == source]
        targets = self.labels[self.labels == source]
        self.data = data
        self.labels = targets


class SoftLabelCIFAR10(datasets.CIFAR10):
    def __init__(self, root, train, download, soft_label, transform=None):
        super(SoftLabelCIFAR10, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftLabelCIFAR100(datasets.CIFAR100):
    def __init__(self, root, train, download, soft_label, transform=None):
        super(SoftLabelCIFAR100, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img)
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftLabelMNIST(datasets.MNIST):
    def __init__(self, root, train, download, soft_label, transform=None):
        super(SoftLabelMNIST, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img.numpy(), mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftLabelFashion(datasets.FashionMNIST):
    def __init__(self, root, train, download, soft_label, transform=None):
        super(SoftLabelFashion, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img.numpy(), mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftLabelKMNIST(datasets.KMNIST):
    def __init__(self, root, train, download, soft_label, transform=None):
        super(SoftLabelKMNIST, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img.numpy(), mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftLabelEMNIST(datasets.EMNIST):
    def __init__(self, root, train, download, soft_label, transform=None, split='letters'):
        super(SoftLabelEMNIST, self).__init__(root=root, train=train, download=download,
                                              transform=transform, split=split)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img.numpy(), mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target

def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo)
    return dict


class IMAGENET32(data.Dataset):
    def __init__(self, root, train=True,
                 transform=None, lbl_range=(0, 1000), id_range=(1, 11)):
        self.root = root
        self.transform = transform
        self.train = train
        self.lbl_range = lbl_range
        self.id_range = id_range

        self.data = []
        self.targets = []
        if self.train:
            for idx in range(id_range[0], id_range[1]):
                if lbl_range[1] == 1002:
                    x, y = unpickle(os.path.join(self.root, 'Imagenet32_train/train_batch_py2_') + str(idx))
                else:
                    x, y = self.loaddata(os.path.join(self.root, 'Imagenet32_train/train_data_batch_') + str(idx))
                if lbl_range[1] == 1001:
                    with open(os.path.join(self.root, 'Imagenet32_train/train_batch_py2_') + str(idx), 'wb') as fo:
                        pickle.dump((x, y), fo, 2)

                self.data.append(x)
                self.targets.extend(y)

        else:
            x, y = self.loaddata(os.path.join(self.root, 'Imagenet32_val/val_data'))
            self.data.append(x)
            self.targets.extend(y)

        self.data = np.vstack(self.data).reshape(-1, 3, 32, 32)
        self.data = self.data.transpose((0, 2, 3, 1))

        self.targets = [y - 1 for y in self.targets]

        if lbl_range[0] > 0 or lbl_range[1] < 1000:
            _data = self.data
            _targets = self.targets
            self.data = []
            self.targets = []

            for i in range(_data.shape[0]):
                if _targets[i] >= lbl_range[0] and _targets[i] < lbl_range[1]:
                    self.data.append(_data[i])
                    self.targets.append(_targets[i])

            self.data = np.stack(self.data)

    def loaddata(self, path):
        d = unpickle(path)
        return d['data'], d['labels']

    def __getitem__(self, index):
        img, target = self.data[index], self.targets[index]
        img = Image.fromarray(img)
        if self.transform is not None:
            img = self.transform(img)
        return img, target

    def __len__(self):
        return len(self.data)

class TinyImageNet_REMOVED(Dataset):
    """
    Tiny ImageNet dataset (200 classes).
    Images are resized to 32x32 to match the expected input size.
    """
    def __init__(self, root, train=True, transform=None, download=False, lbl_range=None):
        """
        Args:
            root (str): Path to dataset root (e.g., 'data/tiny-imagenet-200').
            train (bool): Load training set if True, else validation set.
            transform (callable): Transform to apply.
            download (bool): Not used (dataset is already downloaded).
            lbl_range (tuple, optional): (start, end) to keep only labels in this range.
                                         Labels are remapped to 0..(end-start-1).
        """
        self.root = root
        self.train = train
        self.transform = transform
        self.lbl_range = lbl_range

        if train:
            # Training set: each class folder under 'train/'
            data_dir = os.path.join(root, 'train')
            classes = sorted(os.listdir(data_dir))
            self.class_to_idx = {cls: i for i, cls in enumerate(classes)}
            self.samples = []
            for cls in classes:
                cls_dir = os.path.join(data_dir, cls, 'images')
                for img_name in os.listdir(cls_dir):
                    if img_name.endswith('.JPEG'):
                        img_path = os.path.join(cls_dir, img_name)
                        self.samples.append((img_path, self.class_to_idx[cls]))
        else:
            # Validation set: images in 'val/images', labels in 'val/val_annotations.txt'
            data_dir = os.path.join(root, 'val')
            images_dir = os.path.join(data_dir, 'images')
            annot_file = os.path.join(data_dir, 'val_annotations.txt')
            with open(annot_file, 'r') as f:
                lines = f.readlines()
            # Build class list from annotation file
            class_set = set()
            self.samples = []
            for line in lines:
                parts = line.strip().split('\t')
                img_name = parts[0]
                cls = parts[1]
                class_set.add(cls)
                img_path = os.path.join(images_dir, img_name)
                self.samples.append((img_path, cls))
            # Create mapping from class name to index
            classes = sorted(class_set)
            self.class_to_idx = {cls: i for i, cls in enumerate(classes)}
            # Convert label strings to indices
            self.samples = [(path, self.class_to_idx[cls]) for path, cls in self.samples]

        # Filter by label range if specified
        if self.lbl_range is not None:
            start, end = self.lbl_range
            self.samples = [(path, label) for path, label in self.samples if start <= label < end]
            # Remap labels to 0..(end-start-1)
            self.samples = [(path, label - start) for path, label in self.samples]
            self.num_classes = end - start
        else:
            self.num_classes = len(self.class_to_idx)

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        img = Image.open(img_path).convert('RGB')
        # Resize to 32x32 to match expected input size
        img = img.resize((32, 32), Image.BILINEAR)
        if self.transform:
            img = self.transform(img)
        return img, label

class SoftIMAGENET32(IMAGENET32):
    def __init__(self, root, train, transform, lbl_range, id_range, soft_label):
        super(SoftIMAGENET32, self).__init__(root, train, transform, lbl_range, id_range)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img)
        if self.transform is not None:
            img = self.transform(img)
        return img, target

class GrayCIFAR10(datasets.CIFAR10):
    def __init__(self, root, train, download, transform=None):
        super(GrayCIFAR10, self).__init__(root=root, train=train, download=download, transform=transform)
        self.data = self.data[:, :28, :28, 0]

    def __getitem__(self, index: int):
        img, target = self.data[index], int(self.targets[index])
        img = Image.fromarray(img, mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target


class SoftGrayCIFAR10(GrayCIFAR10):
    def __init__(self, root, train, download, transform, soft_label):
        super(SoftGrayCIFAR10, self).__init__(root=root, train=train, download=download, transform=transform)
        self.soft_label = soft_label

    def __getitem__(self, index):
        img, target = self.data[index], self.soft_label[index]
        img = Image.fromarray(img, mode='L')
        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            target = self.target_transform(target)
        return img, target

class PseudoLabelDataset(Dataset):
    """Documentation.：Documentation.，Documentation."""
    def __init__(self, base_dataset, pseudo_labels):
        self.base_dataset = base_dataset
        self.pseudo_labels = pseudo_labels

    def __len__(self):
        return len(self.base_dataset)

    def __getitem__(self, idx):
        img, _ = self.base_dataset[idx]  # Describe the next operation.
        return img, self.pseudo_labels[idx]
