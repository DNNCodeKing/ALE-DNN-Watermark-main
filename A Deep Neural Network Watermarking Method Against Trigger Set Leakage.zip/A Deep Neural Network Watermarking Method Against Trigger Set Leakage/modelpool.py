clean_model_path = {
    'fashion': [
        "logs/fashion/clean/03-19-14-06-fashion_clean/last.pt",
        'logs/fashion/clean/03-19-15-27-fashion_clean/last.pt',
        "logs/fashion/clean/03-27-12-31-fashion_clean/last.pt",
        'logs/fashion/clean/06-21-10-26-fashion_clean/last.pt',
        'logs/fashion/clean/07-08-16-38-fashion_clean/last.pt',
        'logs/fashion/clean/07-08-17-04-fashion_clean/last.pt',
        'logs/fashion/clean/07-08-17-15-fashion_clean/last.pt',
        'logs/fashion/clean/07-08-18-46-fashion_clean/last.pt',
        'logs/fashion/clean/07-08-18-55-fashion_clean/last.pt'
        # ...
    ],
    'cifar10': [
        'logs/cifar10/clean/03-19-17-32-cifar10_clean/last.pt',
        'logs/cifar10/clean/03-19-18-05-cifar10_clean/last.pt',
        'logs/cifar10/clean/05-09-18-11-cifar10_clean/last.pt',
        'logs/cifar10/clean/05-27-18-14-cifar10_clean/last.pt',
        'logs/cifar10/clean/06-19-10-27-cifar10_clean/last.pt',
        'logs/cifar10/clean/07-06-20-57-cifar10_clean/last.pt',
        'logs/cifar10/clean/07-06-21-59-cifar10_clean/last.pt',
        'logs/cifar10/clean/07-06-22-53-cifar10_clean/last.pt',
        'logs/cifar10/clean/07-06-23-28-cifar10_clean/last.pt'
        # ...
    ],
    'cifar100': [
        'logs/cifar100/clean/03-11-14-44-cifar100_clean/last.pt',
        'logs/cifar100/clean/03-23-22-54-cifar100_clean/last.pt',
        'logs/cifar100/clean/05-15-15-08-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-07-20-40-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-07-21-17-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-07-21-50-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-08-10-11-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-08-10-49-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-08-12-24-cifar100_clean/last.pt',
        'logs/cifar100/clean/07-08-14-32-cifar100_clean/last.pt'
        # ...
    ],
    'imagenet32': [
            'logs/imagenet32/clean/04-08-16-15-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/04-22-19-43-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/05-02-12-00-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-08-20-48-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-08-21-41-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-08-22-43-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-09-10-13-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-09-11-44-imagenet32_clean/last.pt',
            'logs/imagenet32/clean/07-09-12-51-imagenet32_clean/last.pt'
            # ...
    ]
    # 'tiny-imagenet-200': [
    #         '/path/to/last.pth',
    #         '/path/to/last.pth',
    #         # ...
    # ]

}

watermark_model_path = {
    # from pe-trained
    'ssw-p': {
        'fashion': [
            # 'logs/fashion/watermark/05-18-21-27-fashion_watermark_306_4/last.pt',
            # 'logs/fashion/watermark/05-19-12-10-fashion_watermark_306_4/last.pt',
            # 'logs/fashion/watermark/05-19-14-04-fashion_watermark_306_4/last.pt',
            # 'logs/fashion/watermark/07-15-09-24-fashion_watermark_01/last.pt',
            # 'logs/fashion/watermark/07-15-09-26-fashion_watermark_01/last.pt',
            # 'logs/fashion/watermark/07-15-09-30-fashion_watermark_01/last.pt',
            # 'logs/fashion/watermark/07-15-09-34-fashion_watermark_03/last.pt',
            # 'logs/fashion/watermark/07-15-09-39-fashion_watermark_03/last.pt',
            # 'logs/fashion/watermark/07-15-09-42-fashion_watermark_03/last.pt'
            # 'logs/fashion/watermark/07-15-09-50-fashion_watermark_05/last.pt',
            # 'logs/fashion/watermark/07-15-09-58-fashion_watermark_05/last.pt',
            # 'logs/fashion/watermark/07-15-10-01-fashion_watermark_05/last.pt'
            # 'logs/fashion/watermark/07-15-10-17-fashion_watermark_08/last.pt',
            # 'logs/fashion/watermark/07-15-10-20-fashion_watermark_08/last.pt',
            # 'logs/fashion/watermark/07-15-10-23-fashion_watermark_08/last.pt'
            # 'logs/fashion/watermark/07-15-11-25-fashion_watermark_07/last.pt',
            # 'logs/fashion/watermark/07-15-11-29-fashion_watermark_07/last.pt',
            # 'logs/fashion/watermark/07-15-11-33-fashion_watermark_07/last.pt'
            # 'logs/fashion/watermark/07-15-14-19-fashion_watermark_1/last.pt',
            # 'logs/fashion/watermark/07-15-14-22-fashion_watermark_1/last.pt',
            # 'logs/fashion/watermark/07-15-14-25-fashion_watermark_1/last.pt'
            # 'logs/fashion/watermark/07-15-16-41-fashion_watermark_15/last.pt',
            # 'logs/fashion/watermark/07-16-19-25-fashion_watermark_15/last.pt',
            # 'logs/fashion/watermark/07-16-19-29-fashion_watermark_15/last.pt'
            'logs/fashion/watermark/07-15-20-09-fashion_watermark/last.pt',
            'logs/fashion/watermark/07-15-20-13-fashion_watermark/last.pt',
            'logs/fashion/watermark/07-15-20-18-fashion_watermark/last.pt'
            # ...
        ],
        'cifar10': [
            # 'logs/cifar10/watermark/05-20-16-18-cifar10_watermark_306_5/last.pt',
            # 'logs/cifar10/watermark/05-20-19-11-cifar10_watermark_306_5/last.pt',
            # 'logs/cifar10/watermark/05-27-19-08-cifar10_watermark_306_5/last.pt',
            # double
            # 'logs/cifar10/watermark/05-20-16-18-cifar10_watermark_306_5/attack/retrain/retrain/last.pt',
            # 'logs/cifar10/watermark/05-20-16-18-cifar10_watermark_306_5/attack/retrain/retrain2/last.pt',
            # 'logs/cifar10/watermark/05-20-16-18-cifar10_watermark_306_5/attack/retrain/retrain3/last.pt',
            # 'logs/cifar10/watermark/05-20-19-11-cifar10_watermark_306_5/attack/retrain/retrain/last.pt',
            # 'logs/cifar10/watermark/05-20-19-11-cifar10_watermark_306_5/attack/retrain/retrain2/last.pt',
            # 'logs/cifar10/watermark/05-20-19-11-cifar10_watermark_306_5/attack/retrain/retrain3/last.pt',
            # 'logs/cifar10/watermark/05-27-19-08-cifar10_watermark_306_5/attack/retrain/retrain/last.pt',
            # 'logs/cifar10/watermark/05-27-19-08-cifar10_watermark_306_5/attack/retrain/retrain4/last.pt',
            # 'logs/cifar10/watermark/05-27-19-08-cifar10_watermark_306_5/attack/retrain/retrain5/last.pt'
            # 'logs/cifar10/watermark/08-26-09-01-cifar10_watermark_01/last.pt',
            # 'logs/cifar10/watermark/08-26-09-04-cifar10_watermark_01/last.pt',
            # 'logs/cifar10/watermark/08-26-09-07-cifar10_watermark_01/last.pt'
            # 'logs/cifar10/watermark/08-26-09-15-cifar10_watermark_03/last.pt',
            # 'logs/cifar10/watermark/08-26-09-18-cifar10_watermark_03/last.pt',
            # 'logs/cifar10/watermark/08-26-09-21-cifar10_watermark_03/last.pt'
            # 'logs/cifar10/watermark/08-26-09-26-cifar10_watermark_05/last.pt',
            # 'logs/cifar10/watermark/08-26-09-29-cifar10_watermark_05/last.pt',
            # 'logs/cifar10/watermark/08-26-09-33-cifar10_watermark_05/last.pt'
            # 'logs/cifar10/watermark/08-26-09-36-cifar10_watermark_07/last.pt',
            # 'logs/cifar10/watermark/08-26-09-38-cifar10_watermark_07/last.pt',
            # 'logs/cifar10/watermark/08-26-09-41-cifar10_watermark_07/last.pt'
            # 'logs/cifar10/watermark/08-26-09-44-cifar10_watermark_10/last.pt',
            # 'logs/cifar10/watermark/08-26-09-47-cifar10_watermark_10/last.pt',
            # 'logs/cifar10/watermark/08-26-09-50-cifar10_watermark_10/last.pt'
            # 'logs/cifar10/watermark/08-31-14-05-cifar10_watermark_15/last.pt',
            # 'logs/cifar10/watermark/08-31-14-08-cifar10_watermark_15/last.pt',
            # 'logs/cifar10/watermark/08-31-14-11-cifar10_watermark_15/last.pt',
            # 'logs/cifar10/watermark/08-31-14-18-cifar10_watermark_15/last.pt'
            'logs/cifar10/watermark/05-20-17-06-cifar10_watermark_s_5/last.pt',
            'logs/cifar10/watermark/05-20-18-13-cifar10_watermark_s_5/last.pt',
            'logs/cifar10/watermark/05-27-18-57-cifar10_watermark_s/last.pt',
            'logs/cifar10/watermark/05-27-19-03-cifar10_watermark_s/last.pt'
            # '/path/to/last.pth',
            # ...
        ],
        'cifar100': [
            # 'logs/cifar100/watermark/05-20-11-11-cifar100_watermark_306_8/last.pt',
            # 'logs/cifar100/watermark/05-31-19-58-cifar100_watermark_306_8/last.pt',
            # 'logs/cifar100/watermark/05-31-21-14-cifar100_watermark_306_8/last.pt'
            #double
            'logs/cifar100/watermark/05-20-11-11-cifar100_watermark_306_8/attack/retrain/retrain/last.pt',
            'logs/cifar100/watermark/05-20-11-11-cifar100_watermark_306_8/attack/retrain/retrain2/last.pt',
            'logs/cifar100/watermark/05-20-11-11-cifar100_watermark_306_8/attack/retrain/retrain3/last.pt',
            'logs/cifar100/watermark/05-31-19-58-cifar100_watermark_306_8/attack/retrain/retrain/last.pt',
            'logs/cifar100/watermark/05-31-19-58-cifar100_watermark_306_8/attack/retrain/retrain5/last.pt',
            'logs/cifar100/watermark/05-31-19-58-cifar100_watermark_306_8/attack/retrain/retrain6/last.pt',
            'logs/cifar100/watermark/05-31-21-14-cifar100_watermark_306_8/attack/retrain/retrain/last.pt',
            'logs/cifar100/watermark/05-31-21-14-cifar100_watermark_306_8/attack/retrain/retrain2/last.pt',
            'logs/cifar100/watermark/05-31-21-14-cifar100_watermark_306_8/attack/retrain/retrain3/last.pt'
            # ...
        ],
        'imagenet32': [
            # #EXF
            # 'logs/imagenet32/watermark/05-21-13-59-imagenet32_watermark_306/last.pt',
            # 'logs/imagenet32/watermark/05-21-14-26-imagenet32_watermark_306/last.pt',
            # 'logs/imagenet32/watermark/05-22-09-37-imagenet32_watermark_306/last.pt',
            # 'logs/imagenet32/watermark/05-22-10-46-imagenet32_watermark_306/last.pt'
            # #double
            # 'logs/imagenet32/watermark/05-21-13-59-imagenet32_watermark_306/attack/retrain/retrain/last.pt',
            # 'logs/imagenet32/watermark/05-21-13-59-imagenet32_watermark_306/attack/retrain/retrain2/last.pt',
            # 'logs/imagenet32/watermark/05-21-13-59-imagenet32_watermark_306/attack/retrain/retrain3/last.pt',
            # 'logs/imagenet32/watermark/05-21-14-26-imagenet32_watermark_306/attack/retrain/retrain/last.pt',
            # 'logs/imagenet32/watermark/05-21-14-26-imagenet32_watermark_306/attack/retrain/retrain2/last.pt',
            # 'logs/imagenet32/watermark/05-21-14-26-imagenet32_watermark_306/attack/retrain/retrain3/last.pt',
            # 'logs/imagenet32/watermark/05-22-09-37-imagenet32_watermark_306/attack/retrain/retrain/last.pt',
            # 'logs/imagenet32/watermark/05-22-09-37-imagenet32_watermark_306/attack/retrain/retrain2/last.pt',
            # 'logs/imagenet32/watermark/05-22-09-37-imagenet32_watermark_306/attack/retrain/retrain3/last.pt',
            # 'logs/imagenet32/watermark/05-22-10-46-imagenet32_watermark_306/attack/retrain/retrain/last.pt',
            # 'logs/imagenet32/watermark/05-22-10-46-imagenet32_watermark_306/attack/retrain/retrain2/last.pt',
            # 'logs/imagenet32/watermark/05-22-10-46-imagenet32_watermark_306/attack/retrain/retrain3/last.pt'
            # #SSW
            # 'logs/imagenet32/watermark/05-22-13-57-imagenet32_watermark_s/last.pt',
            # 'logs/imagenet32/watermark/05-22-16-55-imagenet32_watermark_s/last.pt',
            # 'logs/imagenet32/watermark/05-22-17-38-imagenet32_watermark_s/last.pt'
            #double
            'logs/imagenet32/watermark/05-22-13-57-imagenet32_watermark_s/attack/retrain/retrain/last.pt',
            'logs/imagenet32/watermark/05-22-13-57-imagenet32_watermark_s/attack/retrain/retrain2/last.pt',
            'logs/imagenet32/watermark/05-22-13-57-imagenet32_watermark_s/attack/retrain/retrain3/last.pt',
            'logs/imagenet32/watermark/05-22-16-55-imagenet32_watermark_s/attack/retrain/retrain/last.pt',
            'logs/imagenet32/watermark/05-22-16-55-imagenet32_watermark_s/attack/retrain/retrain2/last.pt',
            'logs/imagenet32/watermark/05-22-16-55-imagenet32_watermark_s/attack/retrain/retrain3/last.pt',
            'logs/imagenet32/watermark/05-22-17-38-imagenet32_watermark_s/attack/retrain/retrain/last.pt',
            'logs/imagenet32/watermark/05-22-17-38-imagenet32_watermark_s/attack/retrain/retrain2/last.pt',
            'logs/imagenet32/watermark/05-22-17-38-imagenet32_watermark_s/attack/retrain/retrain3/last.pt'
             # ...
        ]
        # 'tiny-imagenet-200': [
        #             '/path/to/last.pth',
        #             '/path/to/last.pth',
        #             # ...
        # ]
    },
    # # from scratch
    # 'ssw-s': {
    #     'fashion': [
    #         '/path/to/last.pth',
    #         '/path/to/last.pth',
    #         # ...
    #     ],
    #     'cifar10': [
    #         '/path/to/last.pth',
    #         '/path/to/last.pth',
    #         # ...
    #     ],
    #     'cifar100': [
    #         '/path/to/last.pth',
    #         '/path/to/last.pth',
    #         # ...
    #     ],
    #     'gtsrb': [
    #                 '/path/to/last.pth',
    #                 '/path/to/last.pth',
    #                 # ...
    #     ],
    #     'tiny-imagenet-200': [
    #                 '/path/to/last.pth',
    #                 '/path/to/last.pth',
    #                 # ...
    #     ]
    # }
}
